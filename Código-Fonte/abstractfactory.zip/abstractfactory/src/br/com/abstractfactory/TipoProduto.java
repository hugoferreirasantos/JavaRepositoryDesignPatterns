package br.com.abstractfactory;

public enum TipoProduto {
	
	NOTEBOOK, TELEVISAO;
	
}
