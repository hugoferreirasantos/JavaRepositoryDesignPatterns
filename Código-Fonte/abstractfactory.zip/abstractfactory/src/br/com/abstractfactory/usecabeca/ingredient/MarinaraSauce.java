package br.com.abstractfactory.usecabeca.ingredient;

public class MarinaraSauce implements Sauce {
	@Override
	public String toString() {
		return "Marinara Sauce";
	}
}
