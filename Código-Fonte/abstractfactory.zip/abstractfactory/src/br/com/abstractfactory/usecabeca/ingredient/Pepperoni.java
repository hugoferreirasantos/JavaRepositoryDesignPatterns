package br.com.abstractfactory.usecabeca.ingredient;

public interface Pepperoni {
	public String toString();
}
