package br.com.abstractfactory.usecabeca.ingredient;

public class Garlic implements Veggies {
	
	@Override
	public String toString() {
		return "Garlic";
	}
	
}
