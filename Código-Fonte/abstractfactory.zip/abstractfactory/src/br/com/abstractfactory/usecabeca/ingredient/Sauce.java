package br.com.abstractfactory.usecabeca.ingredient;

public interface Sauce {
	public String toString();
}
