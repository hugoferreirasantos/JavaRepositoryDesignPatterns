package br.com.abstractfactory.usecabeca.ingredient;

public interface Clam {
	public String toString();
}
