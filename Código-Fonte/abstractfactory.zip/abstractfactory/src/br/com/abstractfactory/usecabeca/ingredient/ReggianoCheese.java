package br.com.abstractfactory.usecabeca.ingredient;

public class ReggianoCheese implements Cheese {
	@Override
	public String toString() {
		return "Reggiano Cheese";
	}
}
