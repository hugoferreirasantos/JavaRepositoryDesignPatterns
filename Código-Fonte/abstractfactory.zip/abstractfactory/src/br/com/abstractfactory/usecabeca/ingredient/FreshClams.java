package br.com.abstractfactory.usecabeca.ingredient;

public class FreshClams implements Clam {
	@Override
	public String toString() {
		return "Fresh Clams from Long Island Sound";
	}
}
