package br.com.abstractfactory.usecabeca.ingredient;

public interface Dough {
	public String toString();
}
