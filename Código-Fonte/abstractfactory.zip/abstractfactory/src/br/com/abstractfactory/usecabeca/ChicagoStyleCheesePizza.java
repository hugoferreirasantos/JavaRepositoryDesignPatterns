package br.com.abstractfactory.usecabeca;

public class ChicagoStyleCheesePizza extends Pizza {
	
	public ChicagoStyleCheesePizza(String name, PizzaIngredientFactory pizzaIndredientFactory) {
		super(name, pizzaIndredientFactory);
	}

	public void cut() {
		System.out.println("Cortando a pizza em fatias quadradas");
	}

	@Override
	public void prepare() {
		System.out.println("Preparando" + getName());
		
	}

}
