package br.com.abstractfactory.usecabeca;

public class NYStykeCheesePizza extends Pizza {

	public NYStykeCheesePizza(final String name, final PizzaIngredientFactory pizzaIndredientFactory) {
		super(name, pizzaIndredientFactory);
	}

	@Override
	public void prepare() {
		System.out.println("Preparando: Pizza - Sabor: " + getName());
	}
	
	

}
