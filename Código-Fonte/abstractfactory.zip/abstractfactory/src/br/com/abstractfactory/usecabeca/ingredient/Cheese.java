package br.com.abstractfactory.usecabeca.ingredient;

public interface Cheese {
	public String toString();
}
