package br.com.abstractfactory.usecabeca.ingredient;

public interface Veggies {
	public String toString();
}
